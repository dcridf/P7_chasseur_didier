from flask import Flask, render_template, request, url_for
from sklearn.ensemble import GradientBoostingClassifier
import pickle
import pandas as pd
import numpy as np

app = Flask(__name__)

# Chargement du modèle
gb = pickle.load(open('Api/clas_model.pkl', 'rb'))
# Chargement des données de test transformées
data = pd.read_csv("Api/data_test_for_heroku.csv", sep=',')
# Variables prédictives
X_id = "SK_ID_CURR"
X_columns = data.columns.drop(X_id)

@app.route('/')
@app.route('/index/')
@app.route('/accueil/')
def accueil():

    return render_template('accueil.html')


@app.route('/predict/', methods=['GET'])
def predict():

    features = []
    id = int(request.args.get("client_id"))
    features.append(id)

    data_request = data[data[X_id] == features[0]][X_columns]

    pred = int(gb.predict(data_request)[0])
    pred_proba = round(round(gb.predict_proba(data_request)[0].max(), 2) *100)

    if pred == 0:
        pred_text = "Acceptation du crédit"
    else:
        pred_text = "Refus du crédit"

    return render_template('result.html', classe = str(pred), decision = pred_text, perc = str(pred_proba))

# Exemple d'appel de l'API pour un identifiant client :
    # http://localhost:5000/predict/?client_id=410166
    # http://localhost:5000/predict/?client_id=286094
