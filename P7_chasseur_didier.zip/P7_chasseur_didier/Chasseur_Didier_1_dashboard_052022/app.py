import streamlit as st

import pickle

import pandas as pd
import numpy as np

from sklearn.ensemble import GradientBoostingClassifier

import matplotlib.pyplot as plt

import shap
shap.initjs()

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import altair as alt

import time

def main():
    st.title("MODELE DE SCORING")
    st.sidebar.title("MODELE DE SCORING")

    st.markdown("#### Avis favorable ou défavorable pour l'obtention d'un crédit")
    st.text("Nomenclature : \n - Classe 0 : crédit accepté \t - Classe 1 : crédit rejeté")
    st.text("Caractéristiques du groupe client : \n - Genre \t\t\t - Education \n - Situation de famille \t - Logement occupé")
    st.sidebar.markdown("#### Avis favorable ou défavorable pour l'obtention d'un crédit")

    DATA_URL_I = ("/Users/Didier/PycharmProjects/P7_Dashboard/venv/application_test_for_heroku.csv")
    DATA_URL = ("/Users/Didier/PycharmProjects/P7_Dashboard/venv/data_test_for_heroku.csv")

    #    @st.cache(persist=True)
    def load_data_i():
        # Chargement des données brutes
        data_i = pd.read_csv(DATA_URL_I)
        return data_i

    #    @st.cache(persist=True)
    def load_data():
        # Chargement des données transformées
        data = pd.read_csv(DATA_URL)
        return data

    #    @st.cache(persist=True)
    def load_model():
        # Chargement du modèle
        mdl = pickle.load(open('clas_model.pkl', 'rb'))
        return mdl

    def api(clt, data, data_i, X_id, X_columns):
        # Prédiction de la classe du client
        choice_data = data[data[X_id] == int(clt)][X_columns]
        idx = choice_data.index
        pred = mdl.predict(choice_data)
        pred_proba = np.round(mdl.predict_proba(choice_data), 2)
        pred_p = np.array([max(pred_proba[i]) for i in range(len(pred_proba))])
        choice_data = choice_data.assign(y_pred=pred.astype(int), y_pred_proba=np.round(pred_p, 2))
        # Tableau résultat pour le client
        clt_res = data_i[data_i[X_id] == int(clt)]
        clt_res['DAYS_BIRTH'] = np.floor(clt_res['DAYS_BIRTH'] / -365).astype(int)
        clt_res['DAYS_EMPLOYED'] = np.floor(clt_res['DAYS_EMPLOYED'] / -365).astype(int)
        clt_res['AMT_ANNUITY'] = np.round(clt_res['AMT_ANNUITY'], 2)
        clt_res['AMT_CREDIT'] = np.round(clt_res['AMT_CREDIT'], 2)
        clt_res = clt_res.assign(y_pred=pred.astype(int), y_pred_proba=np.round(pred_p,2))
        # Prédictions de la classe du groupe auquel appartient le client
        choice_data_grp = data[(data['CODE_GENDER_M']==choice_data['CODE_GENDER_M'].values[0]) &
                                (data['CODE_GENDER_F']==choice_data['CODE_GENDER_F'].values[0]) &
                                (data['NAME_EDUCATION_TYPE_Higher education']==choice_data['NAME_EDUCATION_TYPE_Higher education'].values[0]) &
                                (data['NAME_EDUCATION_TYPE_Incomplete higher']==choice_data['NAME_EDUCATION_TYPE_Incomplete higher'].values[0]) &
                                (data['NAME_EDUCATION_TYPE_Secondary / secondary special']==choice_data['NAME_EDUCATION_TYPE_Secondary / secondary special'].values[0]) &
                                (data['NAME_EDUCATION_TYPE_Other']==choice_data['NAME_EDUCATION_TYPE_Other'].values[0]) &
                                (data['NAME_FAMILY_STATUS_Civil marriage']==choice_data['NAME_FAMILY_STATUS_Civil marriage'].values[0]) &
                                (data['NAME_FAMILY_STATUS_Married']==choice_data['NAME_FAMILY_STATUS_Married'].values[0]) &
                                (data['NAME_FAMILY_STATUS_Separated']==choice_data['NAME_FAMILY_STATUS_Separated'].values[0]) &
                                (data['NAME_FAMILY_STATUS_Single / not married']==choice_data['NAME_FAMILY_STATUS_Single / not married'].values[0]) &
                                (data['NAME_FAMILY_STATUS_Widow']==choice_data['NAME_FAMILY_STATUS_Widow'].values[0]) &
                                (data['NAME_FAMILY_STATUS_Other']==choice_data['NAME_FAMILY_STATUS_Other'].values[0]) &
                                (data['NAME_HOUSING_TYPE_House / apartment']==choice_data['NAME_HOUSING_TYPE_House / apartment'].values[0]) &
                                (data['NAME_HOUSING_TYPE_Municipal apartment']==choice_data['NAME_HOUSING_TYPE_Municipal apartment'].values[0]) &
                                (data['NAME_HOUSING_TYPE_Rented apartment']==choice_data['NAME_HOUSING_TYPE_Rented apartment'].values[0]) &
                                (data['NAME_HOUSING_TYPE_With parents']==choice_data['NAME_HOUSING_TYPE_With parents'].values[0]) &
                                (data['NAME_HOUSING_TYPE_Other']==choice_data['NAME_HOUSING_TYPE_Other'].values[0])
                                ][X_columns]
        pred = mdl.predict(choice_data_grp)
        pred_proba = np.round(mdl.predict_proba(choice_data_grp), 2)
        pred_p = np.array([max(pred_proba[i]) for i in range(len(pred_proba))])
        choice_data_grp = choice_data_grp.assign(y_pred=pred.astype(int), y_pred_proba=np.round(pred_p, 2))
        # Tableau résultat pour le groupe auquel appartient le client
        clt_grp_res = data_i.iloc[choice_data_grp.index]
        clt_grp_res['DAYS_BIRTH'] = np.floor(clt_grp_res['DAYS_BIRTH'] / -365).astype(int)
        clt_grp_res['DAYS_EMPLOYED'] = np.floor(clt_grp_res['DAYS_EMPLOYED'] / -365).astype(int)
        clt_grp_res['AMT_ANNUITY'] = np.round(clt_grp_res['AMT_ANNUITY'], 2)
        clt_grp_res['AMT_CREDIT'] = np.round(clt_grp_res['AMT_CREDIT'], 2)
        clt_grp_res = clt_grp_res.assign(y_pred=pred.astype(int), y_pred_proba=np.round(pred_p,2))
        # Prédictions de la classe pour l'ensemble des données
        choice_data_tot = data[X_columns].copy()
        pred = mdl.predict(choice_data_tot)
        pred_proba = mdl.predict_proba(choice_data_tot)
        pred_p = np.array([max(pred_proba[i]) for i in range(len(pred_proba))])
        choice_data_tot = choice_data_tot.assign(y_pred=pred.astype(int), y_pred_proba=np.round(pred_p, 2))
        # Prédictions de la classe pour l'ensemble des données
        global_res = data_i.iloc[choice_data_tot.index]
        global_res['DAYS_BIRTH'] = np.floor(global_res['DAYS_BIRTH'] / -365).astype(int)
        global_res['DAYS_EMPLOYED'] = np.floor(global_res['DAYS_EMPLOYED'] / -365).astype(int)
        global_res['AMT_ANNUITY'] = np.round(global_res['AMT_ANNUITY'], 2)
        global_res['AMT_CREDIT'] = np.round(global_res['AMT_CREDIT'], 2)
        global_res = global_res.assign(y_pred=pred.astype(int), y_pred_proba=np.round(pred_p,2))

        return idx, clt_res, clt_grp_res, global_res


    # Initialisation des données et du modèle
    data_i = load_data_i()
    data = load_data()
    mdl = load_model()

    # Initialisation de l'id client et des données du modèle prédictif
    X_id = "SK_ID_CURR"
    X_columns = data.columns.drop(X_id)

    # Prédiction de la classe du client
    st.sidebar.subheader("### Analyse de crédit")
    choice = st.sidebar.selectbox("Choix client", (data_i['SK_ID_CURR']), key=1)
    idx, clt_res, clt_grp_res, global_res = api(choice, data, data_i, X_id, X_columns)
    clt_grp_res_ypred = clt_grp_res[clt_grp_res['y_pred']==clt_res['y_pred'].values[0]]
    global_res_ypred = global_res[global_res['y_pred']==clt_res['y_pred'].values[0]]

    # Affichage de la classe du client
    if not st.sidebar.checkbox("Close", True, key=2):
        st.markdown("### Analyse de crédit")
        pred = int(clt_res['y_pred'].values[0])
        pred_proba = clt_res['y_pred_proba'].values[0]
        if pred == 1:
            pred_proba = 1 - pred_proba

        bar_progress = st.progress(0)
        if pred_proba < 0.40:
            st.markdown(
            """
            <style>
                .stProgress > div > div > div > div { background-image: linear-gradient(to right, #FF6347, #FF6347); }
            </style>
            """,
            unsafe_allow_html=True)
        elif pred_proba >= 0.40 and pred_proba < 0.70:
            st.markdown(
            """
            <style>
                .stProgress > div > div > div > div { background-image: linear-gradient(to right, #FF6347, #ffA500); }
            </style>
            """,
            unsafe_allow_html=True)
        else:
            st.markdown(
            """
            <style>
                .stProgress > div > div > div > div { background-image: linear-gradient(to right, #FF6347, #00bfff); }
            </style>
            """,
            unsafe_allow_html=True)
        for percent_complete in range(int(np.round(pred_proba*100, 0))):
            time.sleep(0.001)
            bar_progress.progress(percent_complete + 1)
        if pred == 1:
            st.latex(f'REFUS - Prédiction : Classe = {int(pred)} / Solvabilité = {int(np.round(pred_proba*100, 0))} \%')
        else:
            st.latex(f'ACCEPTATION - Prédiction : Classe = {int(pred)} / Solvabilité = {int(np.round(pred_proba*100, 0))} \%')

    # Affichage du postionnement du client
    st.sidebar.subheader("### Positionnement du client")
    pos_liste = ['Age', 'Genre', 'Niveau scolaire', 'Situation de famille', 'Cellule familiale', 'Nombre d\'enfants',
                 'Salaire', 'Ancienneté sur le poste actuel', 'Type de poste',
                 'Type de contrat', 'Montant des biens', 'Montant du crédit', 'Annuités du prêt',
                 'Propriétaire d\'un véhicule (O/N)', 'Propriétaire du logement (O/N)']
    pos_var = ['DAYS_BIRTH', 'CODE_GENDER', 'NAME_EDUCATION_TYPE', 'NAME_FAMILY_STATUS', 'CNT_FAM_MEMBERS', 'CNT_CHILDREN',
               'AMT_INCOME_TOTAL', 'DAYS_EMPLOYED', 'OCCUPATION_TYPE',
               'NAME_CONTRACT_TYPE', 'AMT_GOODS_PRICE', 'AMT_CREDIT', 'AMT_ANNUITY',
               'FLAG_OWN_CAR', 'FLAG_OWN_REALTY']
    pos_choice = st.sidebar.selectbox("Critères", list(pos_liste), key=11)
    pos_choice = pos_var[pos_liste.index(pos_choice)]
    if not st.sidebar.checkbox("Close", True, key=12):
        st.markdown("###  Positionnement du client")
        # Positionnement du client selon le choix effectué
        fig1, fig2 = st.columns(2)
        with fig1:
            fig1 = px.histogram(clt_grp_res_ypred, x=pos_choice, color='y_pred',
                                color_discrete_map={0: 'deepskyblue', 1: 'tomato'},
                                category_orders={'y_pred': [0, 1]},
                                barmode='group', histfunc='count', nbins=50,
                                title=f"Groupe client",
                                labels={'y_pred': 'Classe'},
                                height=350, width=350)
            fig1.add_vline(x=clt_res[pos_choice].values[0],
                           line=dict(color='darkgreen', width=2, dash='dash'))
            st.plotly_chart(fig1)
        with fig2:
            fig2 = px.histogram(global_res_ypred, x=pos_choice, color='y_pred',
                                color_discrete_map={0: 'deepskyblue', 1: 'tomato'},
                                category_orders={'y_pred': [0, 1]},
                                barmode='group', histfunc='count', nbins=50,
                                title=f"Ensemble des données",
                                labels={'y_pred': 'Classe'},
                                height=350, width=350)
            fig2.add_vline(x=clt_res[pos_choice].values[0],
                           line=dict(color='darkgreen', width=2, dash='dash'))
            st.plotly_chart(fig2)


    # Affichage de l'influence des variables
    st.sidebar.subheader("### Influence des variables")
    inf_choice = st.sidebar.selectbox("Type", ['Global', 'Local'], key=21)
    nb_choice = st.sidebar.slider("Nombre de variables", 5, 20, key=22)
    if not st.sidebar.checkbox("Close", True, key=23):
        st.markdown("###  Influence des variables")
        if inf_choice == 'Global':
            indices = np.argsort(np.abs(mdl.feature_importances_))[::-1]
            indices = indices[:int(nb_choice)]
            indices_name = [data[X_columns].columns[j] for j in indices]
            global_features = pd.DataFrame({'Features': indices_name,
                                            'Values': np.abs(mdl.feature_importances_)[indices]})
            global_features['y_pred'] = clt_res['y_pred'].values[0] * len(global_features)
            fig = px.bar(global_features, x='Values', y='Features', color='y_pred',
                          color_discrete_map={0: 'deepskyblue', 1: 'tomato'},
                          category_orders={'y_pred': [0, 1]},
                          barmode='group', text_auto=True,
                          labels={'y_pred': 'Classe'},
                          title=f"Influence globale")
            fig.update_traces(showlegend=False)
            st.plotly_chart(fig)
        if inf_choice == 'Local':
            # Feature Importances
            st.set_option('deprecation.showPyplotGlobalUse', False)
            explainer = shap.TreeExplainer(mdl, masker=data[X_columns])
            fig = shap.decision_plot(explainer.expected_value,
                                      explainer.shap_values(data[X_columns].iloc[idx[0]]),
                                      data[X_columns].iloc[idx[0]], feature_names=np.array(X_columns),
                                      feature_display_range=slice(None, -(int(nb_choice)+1), -1),
                                      title=f"Influence locale")
            st.pyplot(fig)


    # Affichage des dépendances des variables
    st.sidebar.subheader("### Dépendance des variables")
    var1_liste = ['Age', 'Cellule familiale', 'Nombre d\'enfants',
                 'Salaire', 'Ancienneté sur le poste actuel',
                 'Montant des biens', 'Montant du crédit', 'Annuités du prêt']
    var2_liste = var1_liste
    var1_var = ['DAYS_BIRTH', 'CNT_FAM_MEMBERS', 'CNT_CHILDREN',
               'AMT_INCOME_TOTAL', 'DAYS_EMPLOYED',
               'AMT_GOODS_PRICE', 'AMT_CREDIT', 'AMT_ANNUITY']
    var2_var = var1_var
    var1_choice = st.sidebar.selectbox("Choix", list(var1_liste), key=31)
    var1_choice = var1_var[var1_liste.index(var1_choice)]
    var2_choice = st.sidebar.selectbox("Croisement", list(var2_liste), key=32)
    var2_choice = var2_var[var2_liste.index(var2_choice)]
    if not st.sidebar.checkbox("Close", True, key=33):
        st.markdown("###  Dépendance des variables")
        # Dépendance des varibales
        fig1, fig2 = st.columns(2)
        with fig1:
            colorsIdx = {0: 'deepskyblue', 1: 'tomato'}
            cols = clt_grp_res_ypred['y_pred'].map(colorsIdx)
            fig1 = px.scatter(clt_grp_res_ypred, x=var1_choice, y=var2_choice, color='y_pred',
                              category_orders={'y_pred': [0, 1]},
                              title=f"Groupe client",
                              labels={'y_pred': 'Classe'},
                              opacity=.8,
                              height=350, width=350)
            fig1.update_traces(marker=dict(size=5, color=cols), selector=dict(mode='markers'))
            fig1.add_trace(go.Scatter(mode='markers', x=clt_res[var1_choice], y=clt_res[var2_choice],
                                     marker=dict(color='darkgreen', size=10), opacity=.8,
                                     showlegend=False))
            st.plotly_chart(fig1)
        with fig2:
            colorsIdx = {0: 'deepskyblue', 1: 'tomato'}
            cols = global_res_ypred['y_pred'].map(colorsIdx)
            fig2 = px.scatter(global_res_ypred, x=var1_choice, y=var2_choice, color='y_pred',
                              category_orders={'y_pred': [0, 1]},
                              title=f"Ensemble des données",
                              labels={'y_pred': 'Classe'},
                              opacity=.8,
                              height=350, width=350)
            fig2.update_traces(marker=dict(size=5, color=cols), selector=dict(mode='markers'))
            fig2.add_trace(go.Scatter(mode='markers', x=clt_res[var1_choice], y=clt_res[var2_choice],
                                     marker=dict(color='darkgreen', size=10), opacity=.8,
                                     showlegend=False))
            st.plotly_chart(fig2)


if __name__ == '__main__':
    main()
